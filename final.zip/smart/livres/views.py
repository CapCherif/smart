import emprunts
from adherents.models import Adherent
from json.encoder import JSONEncoder
from django.shortcuts import render, redirect
from django.http import JsonResponse
from . models import Livre
from emprunts.models import Emprunt

# Create your views here.
def home(request):
    if "login" not in request.session:
        request.session['login'] = False
    if request.session['login'] == True:
        #fetch  in db

        return render(request, 'livres/home.html')

def AjouterLivre(request):
    
    if 'login' not in request.session:
        request.session['login'] = False
    
    if request.method == "POST" and request.is_ajax:
        # créer nouveau livre
        print('here' * 9)
        print(request.POST)
        livre = Livre()
        livre.auteur = request.POST['auteur']
        livre.editeur = request.POST['editeur']
        livre.date = request.POST['date']
        livre.titre = request.POST['titre']
        livre.specialite = request.POST['specialite']
        livre.cle = request.POST['cle']
        livre.numeroetagere = request.POST['num_etagere']
        livre.nombrecopie = request.POST['num_copie']
        livre.tagid = request.POST['tag_id']

        livre.save()

        return JsonResponse({"done":True})

    else:
        if request.session['login'] == True:
            return render(request, 'livres/ajouter_livre.html')
        else:
            return redirect('/')

def Search(request):
    if request.method == "POST" and request.is_ajax:
        livres = Livre.objects.all()
        res = []
        
        for l in livres:
            livre = l.getObj()
            
            taille = len(request.POST) - 1
            score = 0             

            for k in request.POST.keys():
                if k != "csrfmiddlewaretoken":
                    if request.POST[k] == livre[k]:
                        score += 1
            if score == taille:
                res.append(livre)
        request.session['current_search'] = res
                

        if len(res) != 0:
            return JsonResponse({"res":True})
        else:
            return JsonResponse({"res":False})


def ModifierLivre(request):
    if 'login' not in request.session:
        request.session['login'] = False
    
    
    if request.method == "POST" and request.is_ajax:

        
        c = Livre.objects.get(id = dict(request.POST)['obj[id]'][0])
        
        c.setObj(dict(request.POST)['obj[titre]'][0]
        ,dict(request.POST)['obj[auteur]'][0]
        ,dict(request.POST)['obj[date]'][0]
        ,dict(request.POST)['obj[specialite]'][0]
        ,dict(request.POST)['obj[cle]'][0]
        ,dict(request.POST)['obj[editeur]'][0]
        ,dict(request.POST)['obj[nombrecopie]'][0]
        ,dict(request.POST)['obj[numeroetagere]'][0]
        ,dict(request.POST)['obj[tagid]'][0]
        )

        c.save()
        return JsonResponse({"done":True})
    else:

        if request.session['login'] == True:
            return render(request, "livres/modifier_livre.html")
        else:
            return redirect('/')

def searchById(request):

    if request.method == "POST" and request.is_ajax:
        r = Livre.objects.filter(tagid = request.POST['tagid']).values('id', 'titre','auteur','editeur','numeroetagere',
                                                                         'nombrecopie','tagid','specialite','date','cle')
        
        
        
        if len(r) != 0:
            print(r)
            return JsonResponse({'done':True, "obj":r[0]})
        else:
            print(r)
            return JsonResponse({'done':False})



def SupprimerLivre(request):
    if 'login' not in request.session:
        request.session['login'] = False


    if request.method == "POST" and request.is_ajax:

        Livre.objects.filter(id = request.POST['id']).delete()
        return JsonResponse({"done":True})

    else:

        if request.session['login'] == True:
            return render(request, 'livres/supprimer_livre.html')
        else:
            return redirect('/')




def rechercher(request):
    if 'login' not in request.session:
        request.session['login'] = False
    
    
    if request.session['login'] == True:
        return render(request, 'livres/rechercher.html')
    else:
        return redirect('/')



def SearchAdmin(request):
    if request.method == "POST" and request.is_ajax:
        livres = Livre.objects.all()
        res = []
        
        for l in livres:
            livre = l.getObj()
            
            taille = len(request.POST) - 1
            score = 0             

            for k in request.POST.keys():
                if k != "csrfmiddlewaretoken":
                    if request.POST[k] == livre[k]:
                        score += 1
            if score == taille:
                res.append(livre)
        request.session['current_search_admin'] = res
                

        if len(res) != 0:
            return JsonResponse({"res":True})
        else:
            return JsonResponse({"res":False})


def resultat(request):
    if 'login' not in request.session:
        request.session['login'] = False
    
    

    if request.session['login'] == True:
        return render(request, 'livres/resultat.html', {"res":request.session['current_search_admin']})
    else:
        return redirect('/')


def emprunter(request):
    if 'login' not in request.session:
        request.session['login'] = False
    
    if request.method == "POST" and request.is_ajax:

        livre = Livre.objects.filter(tagid = request.POST['tagid'])
        
        
        if len(livre) != 0:
            # search in empruntsdb for number occurence of tagid
            n = Emprunt.objects.filter(tagid =  request.POST['tagid'])
            print(n)
            
            if livre[0].getObj()['nombrecopie'] > len(n):
                request.session['current_emprunt_id'] = request.POST['tagid']
                return JsonResponse({'done':True, "err":False})

            else:
                return JsonResponse({"done":True, "err":True})
        else:
            return JsonResponse({"done":False})
        

    else:

        if request.session['login'] == True:
            return render(request, 'livres/emprunter.html')
        else:
            return redirect('/')


def emprunterad(request):
    if request.method == "POST":
        print(request.POST['id_adherent'])
        r = Adherent.objects.filter(id_adherent = request.POST['id_adherent'])
        print(r)
        if len(r) != 0:
            if r[0].getEtat() == "pas d'emprunt":
                #register into db emprunt
                Adherent.objects.filter(id_adherent = request.POST['id_adherent']).update(etat = "emprunt")
                emprunt = Emprunt()
                emprunt.id_adherent = request.POST['id_adherent']
                emprunt.tagid = request.session['current_emprunt_id']
                emprunt.save()
                return JsonResponse({"apte":True})
            else:
                return JsonResponse({"apte":False})
        else:
            return JsonResponse({"inexistant":True})

def restituer(request):
    if 'login' not in request.session:
        request.session['login'] = False
    
    if request.method == 'POST' and request.is_ajax:
        r = Emprunt.objects.filter(tagid = request.POST['tagid'])
        if len(r) != 0:
            request.session['id_livre_rest'] = request.POST['tagid']
            return JsonResponse({"rep":True})
        else:
            return JsonResponse({"rep": False})
    else:

        if request.session['login'] == True:
            return render(request,'livres/restituer.html')
        else:
            return redirect('/')

def fn_rest(request):
    if request.method == "POST":
        r = Emprunt.objects.filter(id_adherent = request.POST['id_adherent'])
        print(r)
        if len(r) != 0:
            Emprunt.objects.filter(id_adherent = request.POST['id_adherent']).delete()
            Adherent.objects.filter(id_adherent = request.POST['id_adherent']).update(etat = "pas d'emprunt")
            return JsonResponse({"rest":True})
        else:
            return JsonResponse({"rest":False})



def listeEmprunts(request):
    if 'login' not in request.session:
        request.session['login'] = False

    if request.session['login'] == True:
        res = Emprunt.objects.all()[::-1]
        return render(request, 'livres/liste_emprunts.html', {"res":res})
    else:
        return redirect('/')


def listeLivres(request):
    if 'login' not in request.session:
        request.session['login'] = False

    if request.session['login'] == True:
        res = Livre.objects.all()[::-1]
        return render(request, 'livres/liste_livres.html', {"res":res})
    else:
        return redirect('/')