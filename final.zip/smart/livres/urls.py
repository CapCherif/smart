from django.urls import path

from . import views

urlpatterns = [
    
    path('', views.home, name="home"),
    path('ajouter_livre/', views.AjouterLivre),
    path('search/', views.Search),
    path('modifier_livres/', views.ModifierLivre),
    path('rec_livres/',views.searchById),
    path('supprimer_livre/', views.SupprimerLivre),
    path('rechercher/', views.rechercher),
    path('resultat/', views.resultat),
    path('search_admin/', views.SearchAdmin),
    path('emprunter/', views.emprunter),
    path('emprunterlivre/', views.emprunter),
    path('emprunterlivre_ad/', views.emprunterad),
    path('restituer/', views.restituer),
    path('fnrest/', views.fn_rest),
    path('liste_emprunts/', views.listeEmprunts),
    path('liste_livres/', views.listeLivres)
]  
