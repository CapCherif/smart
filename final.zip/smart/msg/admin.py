from django.contrib import admin
from . models import Msg
# Register your models here.
admin.site.register(Msg)