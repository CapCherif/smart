
from django.urls import path
from . import views


urlpatterns = [
    
    path('consulter_msg/', views.consulter),
    path('envoyer_msg/', views.envoyerMsg)

]
