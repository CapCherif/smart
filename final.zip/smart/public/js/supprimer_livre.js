var cur_id = ""

$('#recmodlivre').submit(function(e){

    e.preventDefault()

    $('.animation').show()
    $('#recmodlivre button').attr('disabled', true)
    $.ajax({
        headers: { "X-CSRFToken": '{{csrf_token}}' },
        type:'POST',
        url:'/livres/rec_livres/',
        data:{"tagid":$('#tgid').val()},
        success:(res)=>{

            $('#recmodlivre button').attr('disabled', false)
            $('#recmodlivre input').val('')
            $('.animation').hide()

            if(res.done){
                $('#detailsuprlivre').slideDown()
                cur_id = res.obj['id']
                $('#titre').text(res.obj['titre'])
                $('#auteur').text(res.obj['auteur'])
                $('#date').text(res.obj['date'])
            }
            else{
                $('.introuvable').slideDown()
                $('#detailsuprlivre').hide()
                setTimeout(() => {
                    $('.introuvable').slideUp()
                }, 2000);
            }
        }
    })
})


$('#detailsuprlivre').submit(function(e){

    e.preventDefault()

    $.ajax({
        headers: { "X-CSRFToken": '{{csrf_token}}' },
        type:'POST',
        url:'/livres/supprimer_livre/',
        data:{"id":cur_id},
        success:(res)=>{
            if(res.done){
                
                $('.animation').hide()
                $('#detailsuprlivre button').attr('disabled', false)
                $('.success').slideDown()
                
                setTimeout(() => {
                    $('.success').slideUp()
                    $('#detailsuprlivre').slideUp()
                }, 2000);
            }
        }
    })

})