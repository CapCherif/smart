
var cur_l = ""

$('#recmodlivre').submit(function(e){

    e.preventDefault()

    $('.animation').show()
    $('#recmodlivre button').attr('disabled', true)
    $.ajax({
        headers: { "X-CSRFToken": '{{csrf_token}}' },
        type:'POST',
        url:'/livres/rec_livres/',
        data:{"tagid":$('#tgid').val()},
        success:(res)=>{
            $('#recmodlivre button').attr('disabled', false)
            $('#recmodlivre input').val('')
            $('.animation').hide()
            if(res.done){
                $('#form_modlivre').slideDown()
                cur_l = res.obj
                /*-- remplir l formulaire --*/
                
                $('#titre').val(res.obj['titre'])
                $('#auteur').val(res.obj['auteur'])
                $('#editeur').val(res.obj['editeur'])
                $('#date').val(res.obj['date'])
                $('#cle').val(res.obj['cle'])
                $('#specialite').val(res.obj['specialite'])
                $('#num_copie').val(res.obj['nombrecopie'])
                $('#num_etagere').val(res.obj['numeroetagere'])
                $('#tag').val(res.obj['tagid'])

            }
            else{
                $('#form_modlivre').hide()
                $('.introuvable').slideDown()
                setTimeout(() => {
                    $('.introuvable').slideUp()
                }, 2000);
            }
        }

    })


})


$('#form_modlivre').submit(function(e){

    e.preventDefault()

    $('.animation').show()
    $('#form_modlivre button').attr('disabled', true)
    var cur_lv = {
        id:cur_l["id"],
        titre:$('#titre').val(),
        auteur:$('#auteur').val(),
        date:$('#date').val(),
        specialite:$('#specialite').val(),
        cle:$('#cle').val(),
        nombrecopie:$('#num_copie').val(),
        numeroetagere:$('#num_etagere').val(),
        editeur:$('#editeur').val(),
        tagid:$('#tag').val()
    }
    
    $.ajax({
        headers: { "X-CSRFToken": '{{csrf_token}}' },
        type:'POST',
        url:'/livres/modifier_livres/',
        data:{"obj":cur_lv},
        success:(res)=>{
            if(res.done){
                $('input').val('')
                $('.animation').hide()
                $('#form_modlivre button').attr('disabled', false)
                $('.success').slideDown()
                
                setTimeout(() => {
                    $('.success').slideUp()
                    $('#form_modlivre').slideUp()
                }, 2000);
            }
        }
    })
})