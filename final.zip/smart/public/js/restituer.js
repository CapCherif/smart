$('#rest').submit(function(e){
    e.preventDefault()

    $('.animation').show()
    $.ajax({
        headers: { "X-CSRFToken": '{{csrf_token}}' },
        type:'POST',
        url:'/livres/restituer/',
        data:{"tagid":$('#id_livre').val()},
        success:function(res){
            $('.animation').hide()
            if(res.rep){
                $('#fnrest').slideDown()
                $('#rest').hide()
            }
            else{
                $('.err_livre').slideDown()
                setTimeout(() => {
                    $('.err_livre').slideUp()
                }, 2000);
            }
        }
    })
})



$('#fnrest').submit(function(e){
    e.preventDefault()
    $('.animation').show()
    $.ajax({
        headers: { "X-CSRFToken": '{{csrf_token}}' },
        type:'POST',
        url:'/livres/fnrest/',
        data:{"id_adherent":$('#id_adherent').val()},
        success:function(res){
            $('.animation').hide()
            $('#id_adherent').val("")
            if(res.rest){
                $('.success').slideDown()               
                setTimeout(() => {
                    window.location.href = "/livres/restituer/"
                }, 2000);
            }
            else{
                $('.adherent_inex').slideDown()
                setTimeout(() => {
                    $('.adherent_inex').slideUp()                    
                }, 2000);
            }
        }
    })
})