$('.link').on('click', function(e){
    $(e.target).parent().find('.sublink').slideToggle()
})


$('#dec').submit(function(e){
    e.preventDefault()
    console.log('cc')
    $.ajax({
        headers: { "X-CSRFToken": '{{csrf_token}}' },
        type:'POST',
        url:'/deconnexion/',
        data:{},
        success:()=>{
            window.location.href="/"
        }
    })
})
