
var amod = ""
$('#suppr_ad').submit(function(e){
    e.preventDefault()

    var id = $('#tgid').val()
    $('.animation').show()
    $.ajax({
        headers: { "X-CSRFToken": '{{csrf_token}}' },
        type:'POST',
        url:'/adherents/supprimer_adherent/',
        data:{id:id},
        success:function(res){
            if(res.rep){
                if(res.emprt){
                    $('.emprtr').slideDown()
                    setTimeout(() => {
                        $('.emprtr').slideUp() 
                    }, 2000);
                }
                else{
                    $('#suppr_ad').hide()
                    amod = res.amod
                    
                    
                    $('#fn_suppr').slideDown()
                    $('#nom').text(amod['nom']).css('color','black')
                    $('#prenom').text(amod['prenom']).css('color','black')
                    $('#email').text(amod['email']).css('color','black')
                }
                
            }
            else{
                $('.introuvable').slideDown()
                setTimeout(() => {
                    $('.introuvable').slideUp()
                }, 2000);
            }

            $('.animation').hide()

        }
    })
})




$('#fn_suppr').submit(function(r){
    r.preventDefault()

    
    $('.animation').show()

    $.ajax({
        headers: { "X-CSRFToken": '{{csrf_token}}' },
        type:'POST',
        url:'/adherents/finaliser_suppr/',
        data:amod,
        success:function(res){
            if(res.done){
                $('.success').slideDown()
                setTimeout(() => {
                    $('.success').slideUp()
                    window.location.href = "/adherents/consulter/"
                }, 2000);
              
            }
            

            $('.animation').hide()

        }
    })

})