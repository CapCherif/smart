$('#login').submit(function(e){

    e.preventDefault()

    if($('#mdp').val() == "" || $('#username').val() == ""){
        $('.saisie').slideDown()
        setTimeout(() => {
            $('.saisie').slideUp()
        }, 2000);
    }

    else{
        $('.animation').show()
        $('.btnlogin').addClass('tealen')
        $.ajax({
            headers: { "X-CSRFToken": '{{csrf_token}}' },
            type:'POST',
            url:'/login/',
            data:{username:$('#username').val(), mdp:$('#mdp').val()},
            success:function(res){
                $('.animation').hide()
                $('#username').val('')
                $('#mdp').val('')
                $('.btnlogin').removeClass('tealen')
                if(res.msg){
                    $('.success').slideDown()
                    setTimeout(() => {
                        $('.success').slideUp()
                        window.location.href = "/livres/"
                    }, 1000);
                }
                else{
                    $('.incorrecte').slideDown()
                    setTimeout(() => {
                        $('.incorrecte').slideUp()
                    }, 2000);
                }
            }   
        })
    }
})