
var amod = ""
$('#modi_ad').submit(function(e){
    e.preventDefault()

    var id = $('#tgid').val()
    $('.animation').show()
    $.ajax({
        headers: { "X-CSRFToken": '{{csrf_token}}' },
        type:'POST',
        url:'/adherents/modifier_adherent/',
        data:{id:id},
        success:function(res){
            if(res.rep){
                if(res.emprt){
                    $('.emprtr').slideDown()
                    setTimeout(() => {
                        $('.emprtr').slideUp() 
                    }, 2000);
                }
                else{
                    $('#modi_ad').hide()
                    amod = res.amod
                    
                    
                    $('#fn_modad').slideDown()
                    $('#nom').val(amod['nom'])
                    $('#prenom').val(amod['prenom'])
                    $('#email').val(amod['email'])
                }
                
            }
            else{
                $('.introuvable').slideDown()
                setTimeout(() => {
                    $('.introuvable').slideUp()
                }, 2000);
            }

            $('.animation').hide()

        }
    })
})


$('#fn_modad').submit(function(r){
    r.preventDefault()

    var amod = {
        nom:$('#nom').val(),
        prenom:$('#prenom').val(),
        email:$('#email').val(),
    }

    $('.animation').show()

    $.ajax({
        headers: { "X-CSRFToken": '{{csrf_token}}' },
        type:'POST',
        url:'/adherents/finaliser_mod/',
        data:amod,
        success:function(res){
            if(res.done){
                $('.success').slideDown()
                setTimeout(() => {
                    $('.success').slideUp()
                    window.location.href = "/adherents/consulter/"
                }, 2000);
              
            }
            

            $('.animation').hide()

        }
    })

})