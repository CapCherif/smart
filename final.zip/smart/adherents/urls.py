from django.urls import path

from . import views

urlpatterns = [
    
    path('ajouter_adherent/', views.ajouteradherent),
    path('ajouter_adh/', views.Submit),
    path('consulter/', views.consulter),
    path('modifier_adherent/', views.modifierAdherent),
    path('finaliser_mod/', views.final),
    path('supprimer_adherent/', views.supprimerAdherent),
    path('finaliser_suppr/', views.finalsuppr),
    path('sanctions/', views.ShowSanctions)
    # path('consulter/', views.consulteradherent)
]   
