from django.contrib import admin
from . models import Emprunt
# Register your models here.

admin.site.register(Emprunt)