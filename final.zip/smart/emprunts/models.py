from django.db import models
from django.db.models.fields import CharField, DateTimeField
import datetime

# Create your models here.

def regular_function():
    return datetime.datetime.now()+datetime.timedelta(days=10)

class Emprunt(models.Model):
    id_adherent = CharField(max_length=100)
    tagid = CharField(max_length=100)
    date_emprunt = models.DateField(auto_now = True)
    date_rest = models.DateField(default=regular_function)
    etat=models.CharField(max_length=10,default="emprunt")

    def __str__(self):
        return self.tagid + " " + self.id_adherent + " " +str(self.date_emprunt)  + "->" + str(self.date_rest)

    def get_date_rest(self):
        return self.date_rest