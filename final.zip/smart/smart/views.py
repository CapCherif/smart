from django.shortcuts import render, redirect
from django.http import JsonResponse

def Acceuil(request):
    if 'login' not in request.session:
        request.session['login'] = False
    if request.session['login'] == False:
        return render(request, 'acceuil.html')
    else:
        return redirect('/livres/')


def resultat(request):
    if 'current_search' not in request.session:
        request.session['current_search'] = []
        
    return render(request, "resultat.html", {'current_search':request.session['current_search']})



def login(request):
    if 'login' not in request.session:
        request.session['login'] = False
    
    if request.method == "POST" and request.is_ajax:
        if request.POST['username'] == "admin123" and request.POST['mdp'] == "test123":
            request.session['login'] = True
            return JsonResponse({'msg':True})
        else:
            return JsonResponse({'msg':False})
    else:

        if request.session['login'] == False:
            return render(request, 'login.html')
        else:
            return redirect('/livres/')

def contact(request):
    if 'login' not in request.session:
        request.session['login'] = False
    
    if request.session['login'] == False:
        return render(request, 'contact.html')
    else:
        return redirect('/livres/')


def deconnexion(request):
    request.session['login'] = False
    return JsonResponse({"md":True})
