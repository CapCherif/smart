from django.db import models

# Create your models here.

class Msg(models.Model):
    adherent_id = models.CharField(max_length=100)
    date_envoi = models.DateTimeField(auto_now_add=True)
    msg = models.TextField(max_length=1000)
    etat = models.CharField(max_length=50, default='non lu')

    def __str__(self):
        return self.adherent_id + " " + str(self.date_envoi) + " " + self.etat
    
    def getMsg(self):
        return self.msg

    def getSubMsg(self):
        return self.msg[0:10] + "..."