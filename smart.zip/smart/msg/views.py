from django.shortcuts import redirect, render
from . models import Msg
from adherents.models import Adherent
from django.http import JsonResponse
# Create your views here.

def consulter(request):
    if 'login' not in request.session:
        request.session['login'] = False
    if request.session['login'] == True:

        r = Msg.objects.all() 
        r = r[::-1]

        return render(request, 'messages/consulter_msg.html', {'res':r})
    else:
        return redirect('/')


def envoyerMsg(request):
    # check if adherent_id exist
    if request.method == "POST" and request.is_ajax:
        r = Adherent.objects.filter(id_adherent = request.POST['id_adherent'])
        if len(r) == 0:
            return JsonResponse({"msg":False})

        else:
            m = Msg()
            m.adherent_id = request.POST['id_adherent']
            m.msg = request.POST['msg']
            m.save()
            return JsonResponse({"msg":True})
