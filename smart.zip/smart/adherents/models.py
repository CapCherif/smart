from django.db import models

# Create your models here.

class Adherent(models.Model):
    nom = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    id_adherent = models.CharField(max_length=100)
    etat = models.CharField(max_length = 100, default="pas d'emprunt")
    def __str__(self):
        return self.nom + " " + self.prenom

    def getEmail(self):
        return self.email

    def getEtat(self):
        return self.etat

    def setEtat(self, n):
        self.etat = n