from django.shortcuts import redirect, render
from django.http import JsonResponse
from . models import Adherent

def consulter(request):
    if 'login' not in request.session:
        request.session['login'] = False

    if request.session['login'] == True:
        r = Adherent.objects.all()

        return render(request,'adherents/consulter.html', {"res":r[::-1]})
    else:
        return redirect('/')
# Create your views here.
def ajouteradherent(request):

    if 'login' not in request.session:
        request.session['login'] = False
   
    if request.method == 'POST' and request.is_ajax:
        r = Adherent.objects.filter(email = request.POST["email"])
        if len(r) == 0:
            return JsonResponse({"res":True})
        else:
            return JsonResponse({"msg":False})
    else:
        if request.session['login'] == True:
            return render(request, 'adherents/ajouter_adherent.html')
        else:
            return redirect('/')

def Submit(request):
    if request.method == "POST" and request.is_ajax:
        adr = Adherent()
        adr.nom = request.POST['nom']
        adr.prenom = request.POST['prenom']
        adr.email = request.POST['email']
        adr.id_adherent = request.POST['id_adherent']
        adr.save()
        return JsonResponse({"res":True})