from django.apps import AppConfig


class AdherentsConfig(AppConfig):
    name = 'adherents'
