from django.urls import path

from . import views

urlpatterns = [
    
    path('ajouter_adherent/', views.ajouteradherent),
    path('ajouter_adh/', views.Submit),
    path('consulter/', views.consulter)
    # path('consulter/', views.consulteradherent)
]   
