from django.contrib import admin
from . models import Adherent
# Register your models here.

admin.site.register(Adherent)