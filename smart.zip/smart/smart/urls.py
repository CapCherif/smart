
from django.contrib import admin
from django.urls import path
from . import views
from django.urls.conf import include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/', views.login),
    path('deconnexion/',views.deconnexion),
    path('', views.Acceuil),
    path('livres/', include("livres.urls")),
    path('resultat/', views.resultat),
    path('contact/', views.contact),
    path('adherents/', include('adherents.urls')),
    path('messages/', include("msg.urls"))

]
 