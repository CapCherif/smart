from django.db import models

# Create your models here.

class Livre(models.Model):
    titre = models.CharField(max_length=100)
    auteur = models.CharField(max_length=100)
    date = models.CharField(max_length=100)
    specialite = models.CharField(max_length=100)
    cle = models.CharField(max_length=100)
    editeur = models.CharField(max_length=100)
    nombrecopie = models.IntegerField()
    numeroetagere = models.CharField(max_length=100)
    tagid = models.TextField(default=1)
    
    def __str__(self):
        return self.titre + " " + self.auteur + " " + self.date
    
    def getObj(self):
        return {
            'titre':self.titre,
            'auteur':self.auteur,
            'date':self.date,
            'specialite':self.specialite,
            'cle':self.cle,
            'editeur':self.editeur,
            'nombrecopie':self.nombrecopie,
            'numeroetagere':self.numeroetagere,
            'tagid':self.tagid
        }
    def setObj(self,titre,auteur,date,specialite,cle,editeur,nombrecopie,numeroetagere, tagid):
        self.titre = titre
        self.auteur = auteur
        self.date = date
        self.specialite = specialite
        self.cle = cle
        self.editeur = editeur
        self.nombrecopie = nombrecopie
        self.numeroetagere = numeroetagere
        self.tagid = tagid