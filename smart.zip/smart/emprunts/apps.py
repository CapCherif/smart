from django.apps import AppConfig


class EmpruntsConfig(AppConfig):
    name = 'emprunts'
