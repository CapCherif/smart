

var crd = {

}



$('#ajouter_adherent').submit(function(e){
    e.preventDefault()

    if($('#nom').val() == "" || $('#prenom').val() == "" || $('#email').val() == ""){
        $('.saisie').slideDown()
        setTimeout(() => {
            $('.saisie').slideUp()
        }, 2000);
    }

    else{
        crd = {
            nom:$('#nom').val(),
            prenom:$('#prenom').val(),
            email:$('#email').val()
        }

        /* check if email is not in bd */
        $('.animation').show()

        $('.btnajouterad').removeClass('.btnajouterad').addClass('lightbtn')
        $.ajax({
            headers: { "X-CSRFToken": '{{csrf_token}}' },
            type:'POST',
            url:'/adherents/ajouter_adherent/',
            data:crd,
            success:(res)=>{
                $('.animation').hide()
                $('.lightbtn').addClass('.btnajouterad').removeClass('lightbtn')
                if(res.res){
                    // show last form
                    $('#ajouter_adherent').hide()
                    $('#scann_id_ad').slideDown()
                }
                else{
                    $('.existdeja').slideDown()
                    setTimeout(() => {
                        $('.existdeja').slideUp()
                    }, 2000);
                }
            }

        })

    }
    
})

$('#scann_id_ad').submit(function(e){
    e.preventDefault()

    if($('#adherent_id').val() == ""){
        $('.saisiead').slideDown()
        setTimeout(() => {
            $('.saisiead').slideUp()
        }, 2000);
    }


    else{
        crd['id_adherent'] = $('#adherent_id').val()

        $('.animation').show()

        $('#btnscan').addClass('lightbtn')

        $.ajax({
            headers: { "X-CSRFToken": '{{csrf_token}}' },
            type:'POST',
            url:'/adherents/ajouter_adh/',
            data:crd,
            success:(res)=>{
                $('.animation').hide()
                $('#btnscan').removeClass('lightbtn')
                if(res.res){
                    // show last form
                    $('#adherent_id').val("")
                    $('.success').slideDown()
                    setTimeout(() => {
                        $('.success').slideUp()
                        window.location.href = "/adherents/consulter/"
                    }, 2000);
                }
            }

        })
    }
})