


$('#graphes #_form').submit(function(e){
    e.preventDefault()
    

    if($('#tag').val() == ""){
        $('.saisie').slideDown()
        setTimeout(() => {
            $('.saisie').slideUp()
        }, 2000);
    }
    else{
        $('.animation').show()
        $('#graphes #_form button').attr('disabled', true)
        $.ajax({
            headers: { "X-CSRFToken": '{{csrf_token}}' },
            type:'POST',
            url:'/livres/emprunterlivre/',
            data:{"tagid":$('#tag').val()},
            success:(res)=>{
                $('.animation').hide()
                $('#graphes #_form button').attr('disabled', false)
                $('#tag').val('')

                if(res.done){
                    if(res.err){
                        $('.indisponible').slideDown()
                        setTimeout(() => {
                            $('.indisponible').slideUp()
                        }, 2000);
                    }
                    else{
                        $('#confirmeremprunt').slideDown()
                        
                        $('#graphes #_form').hide()
                    }
                   
                }
                else{
                    $('.introuvable').slideDown()
                    setTimeout(() => {
                        $('.introuvable').slideUp()
                    }, 2000);
                }
                
            }
        })
    }
    
})



$('#uni #confirmeremprunt').submit(function(d){

    d.preventDefault()
    var id_adherent = $('#idadh').val()
    $('.animation').show()
    $('#confirmeremprunt button').attr('disabled', true)

    $.ajax({
        headers: { "X-CSRFToken": '{{csrf_token}}' },
        type:'POST',
        url:'/livres/emprunterlivre_ad/',
        data:{"id_adherent":id_adherent},
        success:(res)=>{
            if(res.apte){
                $('.animation').hide()
                $('.success').slideDown()
                setTimeout(() => {
                    $('.success').slideUp()
                    window.location.href = '/livres/emprunter/'
                }, 1000);
                
            }

            else if(res.inexistant){
                $('.animation').hide()
                $('#confirmeremprunt button').attr('disabled', false)
                $('.inexistant').slideDown()
                setTimeout(() => {
                    $('.inexistant').slideUp()
                }, 1000);
            }

            else{
                $('.animation').hide()
                $('#confirmeremprunt button').attr('disabled', false)
                $('.dejaemprunt').slideDown()
                setTimeout(() => {
                    $('.dejaemprunt').slideUp()
                }, 1000);
            }
        }
    })
})