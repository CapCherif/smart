$('#contact').submit(function(e){

    e.preventDefault()


    if($('#ad_id').val() == "" || $('#msg').val() == ""){
        $('.saisie').slideDown()
        setTimeout(() => {
            $('.saisie').slideUp()
        }, 2000);
    }

    else{
        /*--*/
        $('.animation').show()

        $('#btnmsg').addClass('tealen')

        $.ajax({
            headers: { "X-CSRFToken": '{{csrf_token}}' },
            type:'POST',
            url:'/messages/envoyer_msg/',
            data:{id_adherent:$('#ad_id').val(), msg:$('#msg').val()},
            success:(r)=>{
                $('.animation').hide()
                $('#ad_id').val('')
                $('#btnmsg').removeClass('tealen')
                $('')
                if(r.msg){
                    $('#msg').val('')
                    $('.success').slideDown()
                    setTimeout(() => {
                        $('.success').slideUp()
                    }, 2000);
                }
                else{
                    $('.introuvable').slideDown()
                    setTimeout(() => {
                        $('.introuvable').slideUp()
                    }, 2000);
                }
            }
        })
    }

})