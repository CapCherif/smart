

$('#scannertag').submit(function(e){

    e.preventDefault()


    var tag = $('#tag').val()

    if(tag != ''){
        obj['tag_id'] = tag
        // ajax
        $('.animation').show()
        $('.scannerbtn').removeClass('scannerbtn').addClass('lightbtn')
        $.ajax({
            headers: { "X-CSRFToken": '{{csrf_token}}' },
            type:'POST',
            url:'/livres/ajouter_livre/',
            data:obj,
            beforeSend:()=>{
                console.log('sending.......')
            },
            success:(res)=>{
                $('.lightbtn').addClass('scannerbtn').removeClass('lightbtn')
                $('#tag').val('')
                $('.animation').hide()
                
                if(res.done){
                    
                    $('.success').slideDown()
                    setTimeout(() => {
                        $('.success').slideUp()     
                        window.location.href="/livres/ajouter_livre/"                   
                    }, 2000);
                }
            }
        })

    }
    else{
        $('.err_scann').slideDown()
        setTimeout(() => {
            $('.err_scann').slideUp()
        }, 2000);
        
    }

})

var obj = {}



$('.continuerbtn').on('click', function(){

     obj = {
        titre:$('#titre').val().toLowerCase(),
        auteur:$('#auteur').val().toLowerCase(),
        specialite:$('#specialite').val().toLowerCase(),
        date:$('#date').val(),
        cle:$('#cle').val().toLowerCase(),
        editeur:$('#editeur').val().toLowerCase(),
        num_copie:parseInt($('#num_copie').val()),
        num_etagere:$('#num_etagere').val()
    }

    
    var c = 0
    for(var k in obj){
        if(k == "num_copie" && !isNaN(obj[k])){
            c = c + 1
        }
        else if(obj[k] != "" && k != "num_copie"){
            
            c = c + 1            
        }
        else{
            break
        }
       
    }

    if(c == 8){
        $('#form_addlivre').hide()
        $('#scannertag').slideDown()

    }
    else{
        //erreur
        $('.saisie').slideDown()
        setTimeout(() => {
            $('.saisie').slideUp()
        }, 2000);
    }
})