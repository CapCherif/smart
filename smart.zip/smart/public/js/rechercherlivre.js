$('#recherche').submit(function(e){
    
    e.preventDefault()

    var obj = {
        titre:$('#titre').val(),
        auteur:$('#auteur').val(),
        specialite:$('#specialite').val(),
        date:$('#date').val(),
        cle:$('#cle').val(),
        editeur:$('#editeur').val()
    }
    var c = 0
    newobj = {}

    for(var k in obj){
        if(obj[k] != ""){
            c = 1
            newobj[k] = obj[k];
        }
    }

    if(c != 0){
        // ajax
        $('.animation').show()
        $.ajax({
            headers: { "X-CSRFToken": '{{csrf_token}}' },
            type:'POST',
            url:'/livres/search_admin/',
            data:newobj,
            success:(res)=>{
                $('.animation').hide()
                console.log(res)
                if(res.res){
                    window.location.href = "/livres/resultat/"
                }
                else{
                    $('.introuvable').slideDown()
                    setTimeout(() => {
                        $('.introuvable').slideUp()
                    }, 2000);
                }
            }
        })
    }
    else{
        //erreur
        $('.saisie').slideDown()
        setTimeout(() => {
            $('.saisie').slideUp()
        }, 2000);
    }
})